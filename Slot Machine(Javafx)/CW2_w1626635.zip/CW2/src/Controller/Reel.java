package Controller;

import Model.Bell;
import Model.Cherry;
import Model.ISymbol;
import Model.Lemon;
import Model.Plum;
import Model.Redseven;
import Model.Watermelon;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class Reel {

    public ISymbol bell, cherry, lemon, plum, redseven, watermelon;
    public ISymbol[] list;

    public ISymbol[] spin() {
        createObject();
        bell.setImage("bell.png");
        bell.setValue(0);
        cherry.setImage("cherry.png");
        cherry.setValue(1);
        lemon.setImage("lemon.png");
        lemon.setValue(2);
        plum.setImage("plum.png");
        plum.setValue(3);
        redseven.setImage("redseven.png");
        redseven.setValue(4);
        watermelon.setImage("watermelon.png");
        watermelon.setValue(5);

        list = new ISymbol[6];
        list[0] = bell;
        list[1] = cherry;
        list[2] = lemon;
        list[3] = plum;
        list[4] = redseven;
        list[5] = watermelon;
        try {
            synchronized (ISymbol.class) {
                list = shuffleArray(list);
            }
        } catch (ArrayIndexOutOfBoundsException ex) {

        }
        return list;
    }

    /*initialize symbol objects*/
    private void createObject() {
        bell = new Bell();
        cherry = new Cherry();
        lemon = new Lemon();
        plum = new Plum();
        redseven = new Redseven();
        watermelon = new Watermelon();

    }

    /*Randomize Array positions */
    private ISymbol[] shuffleArray(ISymbol[] list2) {

        // synchronized (ISymbol.class) {
        Random rnd = ThreadLocalRandom.current();

        try {
            for (int i = list2.length - 1; i > 0; i--) {
                int index = rnd.nextInt(i + 1);
                ISymbol symbol = list2[index];
                list2[index] = list2[i];
                list2[i] = symbol;
            }
        } catch (ArrayIndexOutOfBoundsException ex) {

        }
        // }
        return list2;

    }

}
