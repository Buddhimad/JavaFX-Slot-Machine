package Controller;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Model.Report;
import view.Spins1;
import view.Spins2;
import view.Spins3;

public class Controller {

    public static int bets = 0;
    public static int creditvalue = 10;
    public static ArrayList<Report> reportlist = new ArrayList<>();
    private static Report report;

    /*calculate marks*/
    public static void showMarks() {
        int value1 = Spins1.counter;
        int value2 = Spins2.counter;
        int value3 = Spins3.counter;

        if (value1 == value2 & value2 == value3) {
            creditvalue += bets * value1;
            report = new Report(bets, creditvalue, "Won");
            reportlist.add(report);
        }
        creditvalue -= bets;
        report = new Report(bets, creditvalue, "Loose");
        reportlist.add(report);
    }
/*save Result reports into text file*/
    public static void saveToAFile() {
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd_hh-mm-ss");

        String name = sdf.format(d);
        System.out.println(name);
        try {
            String path = "D:\\" + name + ".txt";
            File f = new File(path);
            if (!f.exists()) {
                f.createNewFile();
            }
            FileWriter fw = new FileWriter(f);
            for (Report r : reportlist) {
                fw.write(r.getBet() + "|" + r.getCreditvalue() + "|" + r.getResult());
            }
            fw.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        System.out.println("Success...");

    }

}
