package Model;

import javafx.scene.image.Image;

public class Watermelon implements ISymbol {

    private Image i;
    private int value;

    @Override
    public void setImage(String name) {
        i = new Image("file:src/img/" + name);

    }

    @Override
    public Image getImage() {
        // TODO Auto-generated method stub
        return i;
    }

    @Override
    public void setValue(int v) {
        value = v;

    }

    @Override
    public int getValue() {
        // TODO Auto-generated method stub
        return value;
    }

}
