package Model;

import javafx.scene.image.Image;

public interface ISymbol {
	public void setImage(String name);
	
	public Image getImage();
	
	public void setValue(int v);
	
	public int getValue();
}
