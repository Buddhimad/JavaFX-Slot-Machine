package Model;

public class Report {
	private int bet;
	private int creditvalue;
	private String result;

	public Report(int bet, int creditvalue, String result) {
		super();
		this.bet = bet;
		this.creditvalue = creditvalue;
		this.result = result;
	}

	public int getBet() {
		return bet;
	}

	public void setBet(int bet) {
		this.bet = bet;
	}

	public int getCreditvalue() {
		return creditvalue;
	}

	public void setCreditvalue(int creditvalue) {
		this.creditvalue = creditvalue;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

}
