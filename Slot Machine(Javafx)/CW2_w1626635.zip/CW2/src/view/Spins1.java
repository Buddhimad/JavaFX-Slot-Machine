package view;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Model.ISymbol;
import Controller.Reel;
import javafx.scene.image.Image;

public class Spins1 extends Thread {
    
    Image i, i2, i3;
    ISymbol[] is;
    public static boolean isRun = true;
    public static int counter;

    @Override
    public void run() {
        Reel real = new Reel();
        isRun = true;
        //is = real.spin();
        while (isRun) {
            try {
                is = real.spin();
                counter = is[0].getValue();
                i = is[0].getImage();
                Slot_Window.imag1.setImage(i);
                
                try {
                    Thread.sleep(20);
                } catch (InterruptedException ex) {
                }
            } catch (Exception ex) {
                
            }
        }
        
    }
    
}
