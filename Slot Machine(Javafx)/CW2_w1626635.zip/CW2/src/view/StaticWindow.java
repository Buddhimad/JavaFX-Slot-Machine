/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import Model.Report;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author Dell
 */
public class StaticWindow extends Application {

    private Stage window;
    Button btnsave, btncancel, btnback;

    @Override
    public void start(Stage primaryStage) throws Exception {
        window = primaryStage;
        GridPane gridpane = new GridPane();
        gridpane.setVgap(30);
        gridpane.setHgap(30);
        Label lbltitle = new Label("Score Board");
        lbltitle.setFont(Font.font(20));
        lbltitle.setStyle(" -fx-text-fill: White;");
        VBox vbox = new VBox();
        HBox hbox = new HBox();

        GridPane.setConstraints(lbltitle, 10, 0);
        gridpane.getChildren().add(lbltitle);
        hbox.getChildren().add(gridpane);
        hbox.setMinWidth(300);
        hbox.setMinWidth(200);
        GridPane grid = getScorePanel();
        GridPane grid1 = getbtnGrid();
        vbox.getChildren().addAll(hbox, grid, grid1);
        vbox.setStyle(""
                + "-fx-border-color:red red blue red; "
                + "-fx-background-color:brown; "
                + "-fx-border-width: 2 2 2 2; "
                + "-fx-border-style: solid solid solid solid;");
        listner();
        Scene scene = new Scene(vbox, 730, 400);
        window.setScene(scene);
        window.show();
    }

    private GridPane getScorePanel() {
        VBox vbox = new VBox();
        HBox hbox;
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 30, 10, 30));
        pane.setPadding(new Insets(10, 30, 10, 30));
        pane.setVgap(10);
        pane.setHgap(10);
        Label lbl1, lbl2, lbl3, lbl4, lbl5, lbl6;
        int i = 1;
        int j = 1;
        for (Report r : Controller.Controller.reportlist) {

            lbl1 = new Label("Bet : ");
            lbl1.setStyle(Slot_Window.cssLayout1);
            GridPane.setConstraints(lbl1, i++, j);
            lbl1.setMinWidth(100);
            lbl2 = new Label(Integer.toString(r.getBet()));
            lbl2.setStyle(Slot_Window.cssLayout1);
            lbl2.setMinWidth(100);
            GridPane.setConstraints(lbl2, i++, j);
            lbl3 = new Label("Credit : ");
            lbl3.setStyle(Slot_Window.cssLayout1);
            lbl3.setMinWidth(100);
            GridPane.setConstraints(lbl3, i++, j);
            lbl4 = new Label(Integer.toString(r.getCreditvalue()));
            lbl4.setStyle(Slot_Window.cssLayout1);
            lbl4.setMinWidth(100);
            GridPane.setConstraints(lbl4, i++, j);
            lbl5 = new Label("Result : ");
            lbl5.setStyle(Slot_Window.cssLayout1);
            lbl5.setMinWidth(100);
            GridPane.setConstraints(lbl5, i++, j);
            lbl6 = new Label(r.getResult());
            lbl6.setStyle(Slot_Window.cssLayout1);
            lbl6.setMinWidth(100);
            GridPane.setConstraints(lbl6, i++, j);
            pane.getChildren().addAll(lbl1, lbl2, lbl3, lbl4, lbl5, lbl6);
            j++;
            i = 1;
        }
        return pane;
    }

    private GridPane getbtnGrid() {
        GridPane grid2 = new GridPane();
        grid2.setPadding(new Insets(10, 30, 10, 30));
        grid2.setPadding(new Insets(10, 30, 10, 30));
        grid2.setVgap(10);
        grid2.setHgap(10);
        btnsave = new Button("Save");
        btnsave.setStyle(Slot_Window.buttonlayout);
        GridPane.setConstraints(btnsave, 1, 0);
        btnback = new Button("Back");
        btnback.setStyle(Slot_Window.buttonlayout);
        GridPane.setConstraints(btnback, 4, 0);
        btncancel = new Button("Cancel");
        btncancel.setStyle(Slot_Window.buttonlayout);
        GridPane.setConstraints(btncancel, 8, 0);

        grid2.getChildren().addAll(btnsave, btnback, btncancel);
        return grid2;
    }

    private void listner() {
        btnsave.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Controller.Controller.saveToAFile();

            }

        });
        btnback.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                new Slot_Window().start(window);

            }

        });
        btncancel.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.exit(0);

            }

        });
    }

}
