/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import com.sun.glass.ui.Window;
import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

import javafx.stage.Stage;
import javax.swing.ImageIcon;

/**
 *
 * @author Dell
 */
public class Slot_Window extends Application {

    Stage window;
    public static Label lblbet, lblbetinfo, lblcredit, lblcreditinfo;
    public static ImageView imag1, imag2, imag3;
    Button btnAddCoin, btnReset, btnBetOne, btnBetMax, btnSpin, btnstatics;
    EventHandler<ActionEvent> btnbetone;
    public Spins1 spin1;
    public Spins2 spin2;
    public Spins3 spin3;
    private HBox hbox, hbox1, hbox2;
    private boolean isspin1 = false;
    private boolean isspin2 = false;
    private boolean isspin3 = false;
    private boolean isbeted = false;
    public static String cssLayout1, buttonlayout;

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        createwindow();
        listner();
    }

    @Override
    public void stop() throws Exception {
        System.exit(0);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /*initialize event listners*/
    private void listner() {

        hbox.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (spin1 != null && spin1.isAlive()) {
                    spin1.stop();
                    spin1 = null;
                    isspin1 = false;
                    if (!isspin1 && !isspin2 && !isspin3) {
                        Controller.Controller.showMarks();
                        Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");
                        Controller.Controller.bets = 0;
                        Slot_Window.lblbetinfo.setText(Controller.Controller.bets + "");
                    }

                }
            }
        });
        hbox1.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (spin2 != null && spin2.isAlive()) {
                    isspin2 = false;
                    spin2.stop();
                    spin2 = null;
                    if (!isspin1 && !isspin2 && !isspin3) {
                        Controller.Controller.showMarks();
                        Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");
                        Controller.Controller.bets = 0;
                        Slot_Window.lblbetinfo.setText(Controller.Controller.bets + "");
                    }
                }
            }
        });
        hbox2.addEventFilter(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (spin3 != null && spin3.isAlive()) {
                    isspin3 = false;
                    spin3.stop();
                    spin3 = null;
                    if (!isspin1 && !isspin2 && !isspin3) {
                        isbeted = false;
                        Controller.Controller.showMarks();
                        Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");
                        Controller.Controller.bets = 0;
                        Slot_Window.lblbetinfo.setText(Controller.Controller.bets + "");
                    }
                }
            }
        });

        btnAddCoin.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Controller.Controller.creditvalue++;
                Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");

            }

        });
        btnBetOne.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!isbeted) {
                    if (spin1 == null && spin2 == null && spin3 == null) {
                        Controller.Controller.bets = 1;
                        isbeted = true;
                        Slot_Window.lblbetinfo.setText(Controller.Controller.bets + "");
                        Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");
                    } else {
                        new Alert(Alert.AlertType.ERROR, "first stop the spin then bet").showAndWait();
                    }
                } else {
                    new Alert(Alert.AlertType.ERROR, "Already bet").showAndWait();
                }
            }

        });
        btnBetMax.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (!isbeted) {
                    if (!isbeted & spin1 == null && spin2 == null && spin3 == null) {
                        Controller.Controller.bets = 3;
                        isbeted = true;
                        Slot_Window.lblbetinfo.setText(Controller.Controller.bets + "");
                        Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");
                    } else {
                        new Alert(Alert.AlertType.ERROR, "first stop the spin then bet").showAndWait();
                    }
                } else {
                    new Alert(Alert.AlertType.ERROR, "Already bet").showAndWait();
                }
            }

        });
        btnReset.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (spin1 == null && spin2 == null && spin3 == null) {
                    Controller.Controller.bets = 0;
                    Slot_Window.lblbetinfo.setText(Controller.Controller.bets + "");
                    Controller.Controller.creditvalue = 10;
                    Slot_Window.lblcreditinfo.setText(Controller.Controller.creditvalue + "");
                } else {
                    new Alert(Alert.AlertType.ERROR, "first stop the spin then Reset..").showAndWait();
                }
            }

        });
        btnSpin.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                if (Controller.Controller.bets != 0) {
                    spin1 = new Spins1();
                    spin1.start();
                    isspin1 = true;
                    spin2 = new Spins2();
                    spin2.start();
                    isspin2 = true;
                    spin3 = new Spins3();
                    spin3.start();
                    isspin3 = true;
                } else {
                    new Alert(Alert.AlertType.ERROR, "Please bet before you spin the wheel...").showAndWait();
                }
            }

        });
        btnstatics.addEventHandler(ActionEvent.ACTION, new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                StaticWindow staticwindow = new StaticWindow();
                try {
                    staticwindow.start(window);
                } catch (Exception ex) {
                    Logger.getLogger(Slot_Window.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
    }

    /*create GUI*/
    private void createwindow() {
        window.setTitle("Slot Machine");
        GridPane grid = new GridPane();
        GridPane grid1 = new GridPane();
        grid.setPadding(new Insets(10, 30, 10, 30));
        grid1.setPadding(new Insets(10, 30, 10, 30));
        grid.setVgap(10);
        grid.setHgap(10);
        grid1.setVgap(10);
        grid1.setHgap(10);
        GridPane grid2 = new GridPane();
        grid2.setPadding(new Insets(10, 30, 10, 30));
        grid2.setPadding(new Insets(10, 30, 10, 30));
        grid2.setVgap(10);
        grid2.setHgap(10);
        btnAddCoin = new Button("Add Coin");
        btnReset = new Button("Reset");
        btnBetOne = new Button("Bet One");
        btnBetMax = new Button("Bet Max");
        btnSpin = new Button("Spin");
        btnstatics = new Button("Statics");
        VBox vbox = new VBox();
        hbox = new HBox();
        hbox1 = new HBox();
        hbox2 = new HBox();
        HBox hbox3 = new HBox();
        HBox hbox4 = new HBox();
        HBox hbox5 = new HBox();
        HBox hbox6 = new HBox();

        Image image = null;
        try {
            image = new Image("file:src/img/bell.png");

        } catch (Exception ex) {
            Logger.getLogger(Slot_Window.class.getName()).log(Level.SEVERE, null, ex);
        }
        imag1 = new ImageView();
        imag1.setImage(image);
        imag1.setPreserveRatio(true);
        imag1.setFitHeight(200);
        imag1.setFitWidth(200);
        imag1.setStyle("-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.8), 10, 0, 0, 0);");
        grid.setStyle(""
                + "-fx-border-color:red red blue red; "
                + "-fx-background-color:brown; "
                + "-fx-border-width: 2 2 2 2; "
                + "-fx-border-style: solid solid solid solid;");
        grid1.setStyle(""
                + "-fx-border-color:white red white red; "
                + "-fx-background-color:white; "
                + "-fx-border-width: 2 2 2 2; "
                + "-fx-border-style: solid solid solid solid;");
        grid2.setStyle(""
                + "-fx-border-color:blue red red red; "
                + "-fx-background-color:brown; "
                + "-fx-border-width: 2 2 2 2; "
                + "-fx-border-style: solid solid solid solid;");
        String cssLayout = "-fx-border-color: red;\n"
                + "-fx-border-insets: 5;\n"
                + "-fx-border-width: 3;\n"
                + "-fx-border-style: solid;\n";

        cssLayout1 = "-fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.8), 10, 0, 0, 0);"
                + "-fx-padding: 10;"
                + "-fx-background-color: white;"
                + "-fx-background-radius: 5;";

        buttonlayout = " -fx-background-color: \n"
                + "        linear-gradient(#ffd65b, #e68400),\n"
                + "        linear-gradient(#ffef84, #f2ba44),\n"
                + "        linear-gradient(#ffea6a, #efaa22),\n"
                + "        linear-gradient(#ffe657 0%, #f8c202 50%, #eea10b 100%),\n"
                + "        linear-gradient(from 0% 0% to 15% 50%, rgba(255,255,255,0.9), rgba(255,255,255,0));\n"
                + "    -fx-background-radius: 30;\n"
                + "    -fx-background-insets: 0,1,2,3,0;\n"
                + "    -fx-text-fill: #654b00;\n"
                + "    -fx-font-weight: bold;\n"
                + "    -fx-font-size: 14px;\n"
                + "    -fx-padding: 10 20 10 20;";
        hbox.setStyle(cssLayout1);
        hbox.getChildren().add(imag1);
        GridPane.setConstraints(hbox, 2, 0);

        Image image1 = null;
        try {
            image1 = new Image("file:src/img/plum.png");

        } catch (Exception ex) {
            Logger.getLogger(Slot_Window.class.getName()).log(Level.SEVERE, null, ex);
        }
        imag2 = new ImageView();
        imag2.setImage(image1);
        imag2.setStyle("-fx-background-color: -fx-shadow-highlight-color,-fx-outer-border,-fx-inner-border,-fx-body-color;"
                + " -fx-background-insets: 0 0 -1 0, 0, 1, 2;"
                + " -fx-background-radius: 3px, 3px, 2px, 1px;");
        imag2.setFitHeight(200);
        imag2.setFitWidth(200);
        hbox1.getChildren().add(imag2);
        hbox1.setStyle(cssLayout1);
        GridPane.setConstraints(hbox1, 4, 0);

        Image image2 = null;
        ImageIcon ico = null;
        try {
            image2 = new Image("file:src/img/cherry.png");

        } catch (Exception ex) {
            Logger.getLogger(Slot_Window.class.getName()).log(Level.SEVERE, null, ex);
        }
        imag3 = new ImageView();
        imag3.setImage(image2);
        imag3.setFitHeight(200);
        imag3.setFitWidth(200);
        hbox2.setStyle(cssLayout1);
        hbox2.getChildren().add(imag3);
        GridPane.setConstraints(hbox2, 6, 0);

        lblbet = new Label("Bet : ");
        Color col = Color.BLUE;
        CornerRadii corn = new CornerRadii(10);
        lblbet.setFont(Font.font(20));
        lblbet.setStyle("-fx-text-fill: red;");
        lblbet.setMinWidth(130);
        hbox3.getChildren().add(lblbet);
        hbox3.setStyle(cssLayout1);

        GridPane.setConstraints(hbox3, 2, 1);

        lblbetinfo = new Label("...");
        lblbetinfo.setMinWidth(150);
        lblbetinfo.setFont(Font.font(15));
        hbox4.setStyle(cssLayout1);
        hbox4.getChildren().add(lblbetinfo);
        GridPane.setConstraints(hbox4, 4, 1);

        lblcredit = new Label("Credit : ");
        lblcredit.setFont(Font.font(20));
        lblcredit.setMinWidth(130);
        lblcredit.setStyle("-fx-text-fill: red;");
        hbox5.getChildren().add(lblcredit);
        hbox5.setStyle(cssLayout1);
        GridPane.setConstraints(hbox5, 6, 1);

        lblcreditinfo = new Label("...");
        lblcreditinfo.setFont(Font.font(15));
        lblcreditinfo.setMinWidth(150);
        hbox6.getChildren().add(lblcreditinfo);
        hbox6.setStyle(cssLayout1);
        GridPane.setConstraints(hbox6, 8, 1);

        btnAddCoin.setStyle(buttonlayout);
        btnAddCoin.setMaxSize(500, 50);

        btnBetOne.setStyle(buttonlayout);
        btnBetOne.setMaxSize(500, 50);
        btnBetOne.setOnAction(btnbetone);
        btnBetMax.setStyle(buttonlayout);
        btnBetMax.setMaxSize(500, 50);
        btnReset.setStyle(buttonlayout);
        btnReset.setMaxSize(500, 50);
        btnSpin.setStyle(buttonlayout);
        btnSpin.setMaxSize(500, 50);
        btnstatics.setStyle(buttonlayout);
        btnstatics.setMaxSize(500, 50);

        GridPane.setConstraints(btnAddCoin, 10, 1);
        GridPane.setConstraints(btnBetOne, 20, 1);
        GridPane.setConstraints(btnBetMax, 30, 1);
        GridPane.setConstraints(btnReset, 10, 2);
        GridPane.setConstraints(btnSpin, 20, 2);
        GridPane.setConstraints(btnstatics, 30, 2);

        grid.getChildren().addAll(hbox, hbox1, hbox2);
        grid1.getChildren().addAll(hbox3, hbox4, hbox5, hbox6);
        grid2.getChildren().addAll(btnAddCoin, btnBetOne, btnBetMax, btnReset, btnSpin, btnstatics);
        vbox.getChildren().add(grid);
        vbox.getChildren().add(grid1);
        vbox.getChildren().add(grid2);

        Scene scene = new Scene(vbox, 800, 453);
        window.setScene(scene);

        window.show();
    }

}
