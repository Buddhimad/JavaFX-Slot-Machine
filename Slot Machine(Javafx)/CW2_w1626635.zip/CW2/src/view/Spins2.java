package view;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Model.ISymbol;
import Controller.Reel;
import javafx.scene.image.Image;

public class Spins2 extends Thread {

    Image i2;
    ISymbol[] is;
    public static int  counter;
    public static boolean isRun = true;

    @Override
    public void run() {
        Reel real = new Reel();
        isRun = true;
        while (isRun) {
            is = real.spin();
            counter = is[0].getValue();
            i2 = is[0].getImage();
            Slot_Window.imag2.setImage(i2);
            
            try {
                Thread.sleep(20);
            } catch (InterruptedException ex) {
            }
            
        }
        
    }
    
}
